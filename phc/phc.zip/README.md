# PHC Faturação

Protótipo funcional e autónomo de um módulo de faturação empresarial inspirado na experiência de utilização do PHC.

## Executar

Abra `index.html` diretamente no navegador ou, nesta pasta, execute:

```powershell
python -m http.server 8080
```

Depois aceda a `http://localhost:8080`.

## Funcionalidades

- painel com indicadores, faturação mensal e valores a receber;
- documentos de venda com pesquisa, filtros e exportação CSV;
- criação de fatura, fatura-recibo, venda a dinheiro, orçamento e nota de crédito;
- linhas de artigos, descontos, IVA e totais automáticos;
- clientes, artigos/serviços e séries documentais;
- pré-visualização e impressão do documento;
- persistência local no navegador (`localStorage`).

Esta versão não substitui um backend fiscal certificado. Para produção, a emissão deve ser ligada à API do Nexora, à numeração transacional, assinatura fiscal, auditoria e base de dados PostgreSQL.
