(() => {
  'use strict';

  const STORAGE_KEY = 'phc-faturacao-v1';
  const today = new Date().toISOString().slice(0, 10);
  const addDays = (date, days) => {
    const value = new Date(`${date}T12:00:00`);
    value.setDate(value.getDate() + days);
    return value.toISOString().slice(0, 10);
  };

  const seed = {
    customers: [
      { id: 1, code: 'CL001', name: 'Moza Construções, Lda.', taxId: '400356721', phone: '+258 84 501 2090', email: 'financeiro@mozaconstrucoes.co.mz', city: 'Maputo', balance: 83450 },
      { id: 2, code: 'CL002', name: 'Kaya Serviços, SA', taxId: '400879234', phone: '+258 82 240 1900', email: 'compras@kaya.co.mz', city: 'Matola', balance: 29700 },
      { id: 3, code: 'CL003', name: 'Horizonte Comercial', taxId: '401201987', phone: '+258 86 111 3004', email: 'geral@horizonte.co.mz', city: 'Beira', balance: 18500 },
      { id: 4, code: 'CL004', name: 'Índico Logística, Lda.', taxId: '400667190', phone: '+258 84 990 2011', email: 'contas@indico.co.mz', city: 'Nampula', balance: 0 },
      { id: 5, code: 'CL005', name: 'Maputo Office', taxId: '401089543', phone: '+258 87 320 1070', email: 'admin@maputooffice.co.mz', city: 'Maputo', balance: 72250 }
    ],
    products: [
      { id: 1, code: 'SRV-001', name: 'Consultoria de gestão', unit: 'Hora', price: 2500, tax: 16, stock: null, active: true },
      { id: 2, code: 'LIC-001', name: 'Licença Software ERP — Mensal', unit: 'Un.', price: 18500, tax: 16, stock: null, active: true },
      { id: 3, code: 'EQP-014', name: 'Terminal POS Android', unit: 'Un.', price: 32000, tax: 16, stock: 18, active: true },
      { id: 4, code: 'SRV-007', name: 'Instalação e parametrização', unit: 'Serv.', price: 12000, tax: 16, stock: null, active: true },
      { id: 5, code: 'PAP-003', name: 'Rolo térmico 80 mm', unit: 'Cx.', price: 1450, tax: 16, stock: 42, active: true },
      { id: 6, code: 'FORM-01', name: 'Formação de utilizadores', unit: 'Dia', price: 8500, tax: 0, stock: null, active: true }
    ],
    series: [
      { id: 1, code: 'A', type: 'FT', description: 'Faturas 2026', year: 2026, next: 48, active: true },
      { id: 2, code: 'A', type: 'FR', description: 'Faturas-recibo 2026', year: 2026, next: 16, active: true },
      { id: 3, code: 'A', type: 'VD', description: 'Vendas a dinheiro 2026', year: 2026, next: 29, active: true },
      { id: 4, code: 'OR', type: 'ORC', description: 'Orçamentos 2026', year: 2026, next: 35, active: true },
      { id: 5, code: 'NC', type: 'NC', description: 'Notas de crédito 2026', year: 2026, next: 7, active: true }
    ],
    documents: [
      { id: 1, type: 'FT', number: 'FT A/2026-000047', customerId: 1, date: '2026-08-08', dueDate: '2026-09-07', subtotal: 62500, discount: 0, tax: 10000, total: 72500, status: 'pending', notes: '', lines: [] },
      { id: 2, type: 'FR', number: 'FR A/2026-000015', customerId: 4, date: '2026-08-07', dueDate: '2026-08-07', subtotal: 32000, discount: 0, tax: 5120, total: 37120, status: 'paid', notes: '', lines: [] },
      { id: 3, type: 'FT', number: 'FT A/2026-000046', customerId: 2, date: '2026-08-05', dueDate: '2026-08-05', subtotal: 25603.45, discount: 0, tax: 4096.55, total: 29700, status: 'overdue', notes: '', lines: [] },
      { id: 4, type: 'ORC', number: 'ORC OR/2026-000034', customerId: 3, date: '2026-08-04', dueDate: '2026-08-19', subtotal: 49500, discount: 2500, tax: 7520, total: 54520, status: 'draft', notes: '', lines: [] },
      { id: 5, type: 'VD', number: 'VD A/2026-000028', customerId: 5, date: '2026-08-03', dueDate: '2026-08-03', subtotal: 12000, discount: 0, tax: 1920, total: 13920, status: 'paid', notes: '', lines: [] },
      { id: 6, type: 'FT', number: 'FT A/2026-000045', customerId: 5, date: '2026-07-29', dueDate: '2026-08-28', subtotal: 62284.48, discount: 0, tax: 9965.52, total: 72250, status: 'pending', notes: '', lines: [] }
    ]
  };

  let state = loadState();
  let currentView = 'dashboard';
  let currentFilter = 'all';

  const root = document.querySelector('#viewRoot');
  const modalRoot = document.querySelector('#modalRoot');
  const money = value => new Intl.NumberFormat('pt-PT', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(Number(value || 0)) + ' MT';
  const datePt = value => value ? new Intl.DateTimeFormat('pt-PT').format(new Date(`${value}T12:00:00`)) : '—';
  const customerById = id => state.customers.find(item => item.id === Number(id));
  const statusLabel = { paid: 'Pago', pending: 'Pendente', overdue: 'Vencido', draft: 'Rascunho', cancelled: 'Anulado' };

  function loadState() {
    try {
      const saved = JSON.parse(localStorage.getItem(STORAGE_KEY));
      return saved && saved.documents ? saved : structuredClone(seed);
    } catch (_) { return structuredClone(seed); }
  }

  function persist() { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); }
  function cloneTemplate(id) { return document.querySelector(id).content.cloneNode(true); }
  function nextId(collection) { return Math.max(0, ...collection.map(item => Number(item.id))) + 1; }
  function escapeHtml(value) { return String(value ?? '').replace(/[&<>'"]/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' })[char]); }
  function toast(message, type = '') {
    const el = document.createElement('div'); el.className = `toast ${type}`; el.textContent = message;
    document.querySelector('#toastRoot').append(el); setTimeout(() => el.remove(), 3200);
  }

  function setView(view) {
    currentView = view;
    document.querySelectorAll('.nav-item[data-view]').forEach(item => item.classList.toggle('active', item.dataset.view === view));
    if (view === 'dashboard') renderDashboard();
    else if (view === 'documents') renderDocuments();
    else if (view === 'customers') renderCustomers();
    else if (view === 'products') renderProducts();
    else if (view === 'series') renderSeries();
    else if (view === 'reports') renderReports();
    history.replaceState(null, '', `#${view}`);
  }

  function renderDashboard() {
    root.replaceChildren(cloneTemplate('#dashboardTemplate'));
    const emitted = state.documents.filter(d => d.status !== 'draft' && d.status !== 'cancelled').reduce((sum, d) => sum + d.total, 0);
    const received = state.documents.filter(d => d.status === 'paid').reduce((sum, d) => sum + d.total, 0);
    const outstanding = state.documents.filter(d => ['pending', 'overdue'].includes(d.status)).reduce((sum, d) => sum + d.total, 0);
    const overdue = state.documents.filter(d => d.status === 'overdue').reduce((sum, d) => sum + d.total, 0);
    const cards = [
      ['Faturação emitida', money(emitted), '↑ 12,4% face ao período anterior', '#008b83'],
      ['Total recebido', money(received), `${Math.round(received / Math.max(emitted, 1) * 100)}% da faturação`, '#2e6ddf'],
      ['Por receber', money(outstanding), `${state.documents.filter(d => ['pending','overdue'].includes(d.status)).length} documentos pendentes`, '#d88a16'],
      ['Vencido', money(overdue), overdue ? 'Requer acompanhamento' : 'Sem valores vencidos', '#d94b4b']
    ];
    document.querySelector('#dashboardStats').innerHTML = cards.map((c, i) => `<article class="stat-card" style="--accent:${c[3]}"><span class="stat-label">${c[0]}</span><strong class="stat-value">${c[1]}</strong><span class="stat-foot ${i === 0 ? 'up' : ''}">${c[2]}</span></article>`).join('');
    const months = ['Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago'];
    const sales = [44, 55, 48, 70, 59, 88], paid = [36, 46, 42, 58, 52, 65];
    document.querySelector('#salesChart').innerHTML = months.map((m, i) => `<div class="bar-group" data-label="${m}"><i class="bar" style="height:${sales[i]}%" title="Emitido"></i><i class="bar received" style="height:${paid[i]}%" title="Recebido"></i></div>`).join('');
    const pending = state.documents.filter(d => ['pending', 'overdue'].includes(d.status)).slice(0, 4);
    document.querySelector('#receivablesList').innerHTML = pending.length ? pending.map(d => `<div class="receivable"><div><b>${escapeHtml(customerById(d.customerId)?.name)}</b><small>${d.number} · vence ${datePt(d.dueDate)}</small></div><strong class="${d.status === 'overdue' ? 'overdue' : ''}">${money(d.total)}</strong></div>`).join('') : '<div class="empty-state">Sem valores pendentes.</div>';
    document.querySelector('#recentDocuments').innerHTML = documentTable(state.documents.slice(0, 5), false);
  }

  function documentTable(items, actions = true) {
    return `<div class="table-wrap"><table><thead><tr><th>Documento</th><th>Cliente</th><th>Emissão</th><th>Vencimento</th><th>Estado</th><th style="text-align:right">Total</th>${actions ? '<th></th>' : ''}</tr></thead><tbody>${items.map(d => `<tr data-document-id="${d.id}"><td><div class="doc-cell"><span class="doc-icon">${d.type}</span><span><b>${escapeHtml(d.number)}</b><small>Documento de venda</small></span></div></td><td>${escapeHtml(customerById(d.customerId)?.name || 'Consumidor final')}</td><td>${datePt(d.date)}</td><td>${datePt(d.dueDate)}</td><td><span class="badge ${d.status}">${statusLabel[d.status] || d.status}</span></td><td style="text-align:right"><b>${money(d.total)}</b></td>${actions ? '<td><button class="row-action" title="Mais ações">•••</button></td>' : ''}</tr>`).join('')}</tbody></table></div>`;
  }

  function setupList({ eyebrow, title, subtitle, primary, headers, rows, count, filters = [], onPrimary }) {
    root.replaceChildren(cloneTemplate('#listTemplate'));
    document.querySelector('#listEyebrow').textContent = eyebrow;
    document.querySelector('#listTitle').textContent = title;
    document.querySelector('#listSubtitle').textContent = subtitle;
    const button = document.querySelector('#listPrimaryAction'); button.textContent = `＋ ${primary}`; button.onclick = onPrimary;
    document.querySelector('#tableHead').innerHTML = `<tr>${headers.map(h => `<th>${h}</th>`).join('')}</tr>`;
    document.querySelector('#tableBody').innerHTML = rows;
    document.querySelector('#tableCount').textContent = `${count} registos`;
    document.querySelector('#filterButtons').innerHTML = filters.map((f, i) => `<button class="filter ${i === 0 ? 'active' : ''}" data-filter="${f[0]}">${f[1]}</button>`).join('');
  }

  function renderDocuments(query = '') {
    setupList({ eyebrow: 'VENDAS', title: 'Documentos', subtitle: 'Consulte e gira todos os documentos de venda.', primary: 'Novo documento', headers: ['Documento','Cliente','Emissão','Vencimento','Estado','Total',''], rows: '', count: state.documents.length, filters: [['all','Todos'],['FT','Faturas'],['FR','Fatura-recibo'],['ORC','Orçamentos'],['pending','Pendentes'],['overdue','Vencidos']], onPrimary: openDocumentModal });
    const renderRows = () => {
      const term = (document.querySelector('#tableSearch').value || query).toLowerCase();
      const items = state.documents.filter(d => (currentFilter === 'all' || d.type === currentFilter || d.status === currentFilter) && `${d.number} ${customerById(d.customerId)?.name}`.toLowerCase().includes(term));
      document.querySelector('#tableBody').innerHTML = items.map(d => `<tr><td><div class="doc-cell"><span class="doc-icon">${d.type}</span><span><b>${escapeHtml(d.number)}</b><small>Documento de venda</small></span></div></td><td>${escapeHtml(customerById(d.customerId)?.name)}</td><td>${datePt(d.date)}</td><td>${datePt(d.dueDate)}</td><td><span class="badge ${d.status}">${statusLabel[d.status]}</span></td><td><b>${money(d.total)}</b></td><td><button class="row-action" data-preview-id="${d.id}">•••</button></td></tr>`).join('') || '<tr><td colspan="7"><div class="empty-state"><b>Nenhum documento encontrado</b>Altere os filtros ou crie um novo documento.</div></td></tr>';
      document.querySelector('#tableCount').textContent = `${items.length} registos`;
    };
    document.querySelector('#tableSearch').value = query;
    document.querySelector('#tableSearch').addEventListener('input', renderRows);
    document.querySelector('#filterButtons').addEventListener('click', e => { if (!e.target.dataset.filter) return; currentFilter = e.target.dataset.filter; document.querySelectorAll('.filter').forEach(b => b.classList.toggle('active', b === e.target)); renderRows(); });
    document.querySelector('#exportBtn').onclick = exportDocuments;
    renderRows();
  }

  function renderCustomers() {
    setupList({ eyebrow: 'ENTIDADES', title: 'Clientes', subtitle: 'Fichas de clientes e respetiva posição financeira.', primary: 'Novo cliente', headers: ['Código','Cliente','NUIT','Contacto','Localidade','Saldo','Estado'], rows: state.customers.map(c => `<tr><td><b>${c.code}</b></td><td><div class="doc-cell"><span class="doc-icon">${escapeHtml(c.name[0])}</span><span><b>${escapeHtml(c.name)}</b><small>${escapeHtml(c.email)}</small></span></div></td><td>${c.taxId}</td><td>${c.phone}</td><td>${c.city}</td><td><b>${money(c.balance)}</b></td><td><span class="badge active">Ativo</span></td></tr>`).join(''), count: state.customers.length, onPrimary: quickCustomer });
    bindSimpleSearch(); document.querySelector('#exportBtn').onclick = () => exportCsv('clientes.csv', state.customers);
  }

  function renderProducts() {
    setupList({ eyebrow: 'CATÁLOGO', title: 'Artigos e serviços', subtitle: 'Preços, impostos e disponibilidade do catálogo.', primary: 'Novo artigo', headers: ['Código','Descrição','Unidade','Preço','IVA','Existência','Estado'], rows: state.products.map(p => `<tr><td><b>${p.code}</b></td><td>${escapeHtml(p.name)}</td><td>${p.unit}</td><td><b>${money(p.price)}</b></td><td>${p.tax}%</td><td>${p.stock ?? 'N/A'}</td><td><span class="badge active">Ativo</span></td></tr>`).join(''), count: state.products.length, onPrimary: quickProduct });
    bindSimpleSearch(); document.querySelector('#exportBtn').onclick = () => exportCsv('artigos.csv', state.products);
  }

  function renderSeries() {
    setupList({ eyebrow: 'CONFIGURAÇÃO', title: 'Séries documentais', subtitle: 'Numeração e sequências por tipo de documento.', primary: 'Nova série', headers: ['Série','Tipo','Descrição','Ano','Próximo número','Estado'], rows: state.series.map(s => `<tr><td><div class="doc-cell"><span class="doc-icon">${s.code}</span><b>${s.type} ${s.code}/${s.year}</b></div></td><td>${s.type}</td><td>${s.description}</td><td>${s.year}</td><td><b>${String(s.next).padStart(6,'0')}</b></td><td><span class="badge active">Ativa</span></td></tr>`).join(''), count: state.series.length, onPrimary: () => toast('A gestão avançada de séries será ligada ao backend fiscal.') });
    bindSimpleSearch(); document.querySelector('#exportBtn').onclick = () => exportCsv('series.csv', state.series);
  }

  function renderReports() {
    root.innerHTML = `<div class="page-head compact"><div><p class="eyebrow">ANÁLISE</p><h1>Relatórios</h1><p>Informação comercial e fiscal pronta para análise.</p></div><button class="btn primary" id="reportExport">⇩ Exportar movimentos</button></div><div class="report-grid">${[['▥','Mapa de faturação','Documentos emitidos por período, tipo e estado.'],['◴','Idade de saldos','Valores pendentes agrupados pelo tempo em dívida.'],['♙','Vendas por cliente','Ranking, volume de vendas e margem por cliente.'],['◇','Vendas por artigo','Quantidade e valor vendido por artigo ou serviço.'],['%','Resumo de IVA','Base tributável e imposto liquidado por taxa.'],['↗','Evolução mensal','Comparativo da faturação e recebimentos mensais.']].map(r => `<article class="panel report-card"><span class="report-icon">${r[0]}</span><h3>${r[1]}</h3><p>${r[2]}</p><button class="link-btn" data-report="${r[1]}">Abrir relatório →</button></article>`).join('')}</div>`;
    document.querySelector('#reportExport').onclick = exportDocuments;
    document.querySelectorAll('[data-report]').forEach(button => button.onclick = () => toast(`${button.dataset.report}: relatório preparado para integração com a API.`));
  }

  function bindSimpleSearch() {
    const input = document.querySelector('#tableSearch');
    input.addEventListener('input', () => document.querySelectorAll('#tableBody tr').forEach(row => row.hidden = !row.textContent.toLowerCase().includes(input.value.toLowerCase())));
  }

  function openDocumentModal(existing = null) {
    modalRoot.replaceChildren(cloneTemplate('#documentModalTemplate'));
    const type = document.querySelector('#docType'), series = document.querySelector('#docSeries'), customer = document.querySelector('#docCustomer');
    customer.innerHTML += state.customers.map(c => `<option value="${c.id}">${escapeHtml(c.code)} — ${escapeHtml(c.name)}</option>`).join('');
    document.querySelector('#docDate').value = existing?.date || today;
    document.querySelector('#docDueDate').value = existing?.dueDate || addDays(today, 30);
    document.querySelector('#docNotes').value = existing?.notes || '';
    if (existing) { type.value = existing.type; customer.value = existing.customerId; document.querySelector('#documentTitle').textContent = existing.number; }
    const updateSeries = () => {
      const matches = state.series.filter(s => s.type === type.value && s.active);
      series.innerHTML = matches.map(s => `<option value="${s.id}">${s.code}/${s.year} — ${s.description}</option>`).join('') || '<option value="">Sem série ativa</option>';
      const selected = matches[0]; document.querySelector('#previewNumber').textContent = selected ? `${type.value} ${selected.code}/${selected.year}-${String(selected.next).padStart(6,'0')}` : `${type.value} —`;
      if (['FR','VD'].includes(type.value)) document.querySelector('#docDueDate').value = document.querySelector('#docDate').value;
    };
    type.addEventListener('change', updateSeries); updateSeries();
    customer.addEventListener('change', updateClientSummary); updateClientSummary();
    document.querySelector('#invoiceLines').addEventListener('input', recalculate);
    if (existing?.lines?.length) existing.lines.forEach(addLine); else addLine();
  }

  function updateClientSummary() {
    const c = customerById(document.querySelector('#docCustomer')?.value);
    document.querySelector('#clientSummary').innerHTML = c ? `<b>${escapeHtml(c.name)}</b> · NUIT ${c.taxId} · ${escapeHtml(c.city)} · ${escapeHtml(c.email)}` : 'Selecione um cliente para preencher os dados fiscais.';
  }

  function addLine(line = {}) {
    const tr = document.createElement('tr');
    tr.innerHTML = `<td><select class="line-product"><option value="">Selecionar artigo…</option>${state.products.map(p => `<option value="${p.id}" ${Number(line.productId) === p.id ? 'selected' : ''}>${escapeHtml(p.code)} — ${escapeHtml(p.name)}</option>`).join('')}</select></td><td><input class="line-number line-qty" type="number" min="0.01" step="0.01" value="${line.quantity || 1}"></td><td><input class="line-number line-price" type="number" min="0" step="0.01" value="${line.price || 0}"></td><td><input class="line-number line-discount" type="number" min="0" max="100" step="0.1" value="${line.discount || 0}"></td><td><select class="line-tax"><option value="16">16%</option><option value="5">5%</option><option value="0">0%</option></select></td><td class="line-total">0,00 MT</td><td><button class="remove-line" title="Remover linha">×</button></td>`;
    tr.querySelector('.line-tax').value = String(line.tax ?? 16);
    tr.querySelector('.line-product').addEventListener('change', e => { const p = state.products.find(item => item.id === Number(e.target.value)); if (p) { tr.querySelector('.line-price').value = p.price; tr.querySelector('.line-tax').value = p.tax; recalculate(); } });
    tr.querySelector('.remove-line').onclick = () => { tr.remove(); if (!document.querySelector('#invoiceLines').children.length) addLine(); recalculate(); };
    document.querySelector('#invoiceLines').append(tr); recalculate();
  }

  function readLines() {
    return [...document.querySelectorAll('#invoiceLines tr')].map(row => ({ productId: Number(row.querySelector('.line-product').value), quantity: Number(row.querySelector('.line-qty').value), price: Number(row.querySelector('.line-price').value), discount: Number(row.querySelector('.line-discount').value), tax: Number(row.querySelector('.line-tax').value) }));
  }

  function calculateTotals() {
    return readLines().reduce((totals, line) => { const gross = line.quantity * line.price; const discount = gross * line.discount / 100; const base = gross - discount; totals.subtotal += gross; totals.discount += discount; totals.tax += base * line.tax / 100; totals.total += base * (1 + line.tax / 100); return totals; }, { subtotal: 0, discount: 0, tax: 0, total: 0 });
  }

  function recalculate() {
    document.querySelectorAll('#invoiceLines tr').forEach(row => { const qty = Number(row.querySelector('.line-qty').value), price = Number(row.querySelector('.line-price').value), discount = Number(row.querySelector('.line-discount').value), tax = Number(row.querySelector('.line-tax').value); row.querySelector('.line-total').textContent = money(qty * price * (1 - discount / 100) * (1 + tax / 100)); });
    const t = calculateTotals(); document.querySelector('#subtotalValue').textContent = money(t.subtotal); document.querySelector('#discountValue').textContent = money(t.discount); document.querySelector('#taxValue').textContent = money(t.tax); document.querySelector('#totalValue').textContent = money(t.total);
  }

  function saveDocument(status) {
    const customerId = Number(document.querySelector('#docCustomer').value), lines = readLines().filter(l => l.productId && l.quantity > 0);
    if (!customerId) return toast('Selecione o cliente do documento.');
    if (!lines.length) return toast('Adicione pelo menos um artigo ou serviço.');
    const type = document.querySelector('#docType').value, selectedSeries = state.series.find(s => s.id === Number(document.querySelector('#docSeries').value));
    if (!selectedSeries) return toast('Não existe uma série ativa para este documento.');
    const totals = calculateTotals();
    const documentData = { id: nextId(state.documents), type, number: `${type} ${selectedSeries.code}/${selectedSeries.year}-${String(selectedSeries.next).padStart(6,'0')}`, customerId, date: document.querySelector('#docDate').value, dueDate: document.querySelector('#docDueDate').value, ...totals, status, notes: document.querySelector('#docNotes').value, reference: document.querySelector('#docReference').value, lines };
    state.documents.unshift(documentData); selectedSeries.next += 1;
    if (status === 'pending') { const c = customerById(customerId); c.balance += totals.total; }
    persist(); modalRoot.replaceChildren(); setView('documents'); toast(status === 'draft' ? 'Rascunho guardado.' : `${documentData.number} emitido com sucesso.`, 'success');
  }

  function quickCustomer() {
    const name = prompt('Nome ou denominação do cliente:'); if (!name?.trim()) return;
    const taxId = prompt('NUIT do cliente:') || '';
    state.customers.push({ id: nextId(state.customers), code: `CL${String(state.customers.length + 1).padStart(3,'0')}`, name: name.trim(), taxId, phone: '', email: '', city: 'Maputo', balance: 0 }); persist();
    if (document.querySelector('#docCustomer')) { const c = state.customers.at(-1); document.querySelector('#docCustomer').insertAdjacentHTML('beforeend', `<option value="${c.id}">${c.code} — ${escapeHtml(c.name)}</option>`); document.querySelector('#docCustomer').value = c.id; updateClientSummary(); }
    else renderCustomers(); toast('Cliente criado.', 'success');
  }

  function quickProduct() {
    const name = prompt('Descrição do artigo ou serviço:'); if (!name?.trim()) return;
    const price = Number(prompt('Preço unitário (MT):') || 0);
    state.products.push({ id: nextId(state.products), code: `ART-${String(state.products.length + 1).padStart(3,'0')}`, name: name.trim(), unit: 'Un.', price, tax: 16, stock: null, active: true }); persist(); renderProducts(); toast('Artigo criado.', 'success');
  }

  function exportCsv(filename, items) {
    if (!items.length) return;
    const keys = Object.keys(items[0]).filter(k => typeof items[0][k] !== 'object');
    const csv = [keys.join(';'), ...items.map(item => keys.map(k => `"${String(item[k] ?? '').replaceAll('"','""')}"`).join(';'))].join('\n');
    const link = document.createElement('a'); link.href = URL.createObjectURL(new Blob(['\ufeff', csv], { type: 'text/csv;charset=utf-8' })); link.download = filename; link.click(); URL.revokeObjectURL(link.href); toast('Ficheiro exportado.', 'success');
  }
  function exportDocuments() { exportCsv('documentos-faturacao.csv', state.documents.map(d => ({ numero: d.number, cliente: customerById(d.customerId)?.name, emissao: d.date, vencimento: d.dueDate, estado: statusLabel[d.status], subtotal: d.subtotal, iva: d.tax, total: d.total }))); }

  document.addEventListener('click', event => {
    const view = event.target.closest('[data-view]')?.dataset.view; if (view) setView(view);
    const action = event.target.closest('[data-action]')?.dataset.action;
    if (action === 'new-document') openDocumentModal();
    if (action === 'close-modal') modalRoot.replaceChildren();
    if (action === 'add-line') addLine();
    if (action === 'quick-customer') quickCustomer();
    if (action === 'save-draft') saveDocument('draft');
    if (action === 'issue-document') saveDocument(['FR','VD'].includes(document.querySelector('#docType').value) ? 'paid' : 'pending');
    if (action === 'preview-document') window.print();
    const previewId = event.target.closest('[data-preview-id]')?.dataset.previewId; if (previewId) openDocumentModal(state.documents.find(d => d.id === Number(previewId)));
  });

  document.querySelector('#globalSearch').addEventListener('keydown', event => { if (event.key === 'Enter') { currentFilter = 'all'; setView('documents'); renderDocuments(event.target.value); } });
  document.addEventListener('keydown', event => { if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'k') { event.preventDefault(); document.querySelector('#globalSearch').focus(); } if (event.key === 'Escape' && modalRoot.children.length) modalRoot.replaceChildren(); });

  setView(location.hash.slice(1) || 'dashboard');
})();
